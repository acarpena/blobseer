#!/bin/bash

if [ ! -e assess.stdin ]
then
    echo 0 >> assess.stdin
    echo $1 >> assess.stdin
    echo 0 >> assess.stdin
    echo 111111011111111 >> assess.stdin
    echo 4 >> assess.stdin
    echo 7 >> assess.stdin
    echo 0 >> assess.stdin
    echo $2 >> assess.stdin
    echo 1 >> assess.stdin
fi

date
./assess 134217728 < assess.stdin
date
rm assess.stdin
